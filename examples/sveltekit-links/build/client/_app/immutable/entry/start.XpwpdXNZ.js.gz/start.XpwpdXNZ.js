import{l as o,d as r}from"../chunks/q77SmO8u.js";export{o as load_css,r as start};
